﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person = new Person();
            Person secongPerson = new Person(10);
            Person thirdPerson = new Person("Gosho", 12);

            Console.WriteLine($"{person.Name} {person.Age}");
            Console.WriteLine($"{secongPerson.Name} {secongPerson.Age}");
            Console.WriteLine($"{thirdPerson.Name} {thirdPerson.Age}");
        }
    }
}
