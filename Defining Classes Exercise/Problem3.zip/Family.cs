﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people = new List<Person>();

        public void AddMember(Person member)
        {
            people.Add(member);
        }

        public Person GetOldestMember()
        {
            Person oldestPerson = new Person();
            foreach(Person member in people)
            {
                if(member.Age > oldestPerson.Age)
                {
                    oldestPerson = member;
                }
            }

            return oldestPerson;
        }
    }
}
