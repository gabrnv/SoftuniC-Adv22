﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class DateModifier
    {
        public static int CalculateDiffrence(string date1, string date2)
        {
            DateTime Date1 = DateTime.Parse(date1);
            DateTime Date2 = DateTime.Parse(date2);
            int diff = (int)Math.Abs((Date1 - Date2).TotalDays);
            return diff;
        }
    }
}
