﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string date1 = Console.ReadLine();
            string date2 = Console.ReadLine();
            Console.WriteLine(DateModifier.CalculateDiffrence(date1, date2));
        }
    }
}
