﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people = new List<Person>();

        public void AddMember(Person member)
        {
            people.Add(member);
        }

        public Person GetOldestMember()
        {
            Person oldestPerson = new Person();
            foreach(Person member in people)
            {
                if(member.Age > oldestPerson.Age)
                {
                    oldestPerson = member;
                }
            }

            return oldestPerson;
        }

        public List<Person> GetPeopleOlderThan30()
        {
            List<Person> newFam = new List<Person>();
            foreach (var member in this.people)
            {
                if(member.Age > 30)
                {
                    newFam.Add(member);
                }
            }
            newFam = newFam.OrderBy(x => x.Name).ToList();
            //Remember orderBy
            return newFam;
        }
    }
}
