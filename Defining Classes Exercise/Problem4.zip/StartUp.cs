﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Family family = new Family();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] info = Console.ReadLine().Split();
                string name = info[0];
                int age = int.Parse(info[1]);
                Person newMember = new Person(name, age);
                family.AddMember(newMember);
            }
            List<Person> olderFamily = family.GetPeopleOlderThan30();
            foreach (Person person in olderFamily)
            {
                Console.WriteLine($"{person.Name} - {person.Age}");
            }
        }
    }
}
