﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ItAndComp
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<string> elements = Console.ReadLine().Split().Skip(1).ToList();
            ListyIterator<string> listy = new ListyIterator<string>(elements);
            string command = Console.ReadLine();
            while(command != "End")
            {
                switch(command)
                {
                    case "HasNext":
                        Console.WriteLine(listy.HasNext());
                        break;
                    case "Print":
                        listy.Print();
                        break;
                    case "PrintAll":
                        listy.PrintAll();
                        break;
                    case "Move":
                        Console.WriteLine(listy.Move());
                        break;
                    
                }
                command = Console.ReadLine();
            }

        }

    }
}
