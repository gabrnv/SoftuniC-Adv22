﻿using System;
using System.Linq;

namespace Generics_Exercise
{
    public class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Box<int> box = new Box<int>();
            for (int i = 0; i < n; i++)
            {
                var value = int.Parse(Console.ReadLine());
                box.Items.Add(value);
            }
            int[] indexesForSwap = Console.ReadLine().Split().Select(int.Parse).ToArray();
            box.Swap(indexesForSwap[0], indexesForSwap[1]);
            Console.WriteLine(box);
        }
    }
}
